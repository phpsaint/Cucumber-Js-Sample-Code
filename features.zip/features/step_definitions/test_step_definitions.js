module.exports = function () {
  this.Given(/^I am on Bing Portal$/,{timeout:  6000}, function (callback) {
    // Express the regexp above with the code you wish you had.
    // `this` is set to a World instance.
    // i.e. you may use this.browser to execute the step:

    this.visit('http://www.bing.com', callback);

    // The callback is passed to visit() so that when the job's finished, the next step can
    // be executed by Cucumber.
  });

    this.When("I enter  $query in search form", function (query,callback) {   
        this.fillFormValue({'#sb_form_q':'google'}, callback);
    });

    this.When(/^Click on Search Icon$/, {timeout:  6000}, function (callback) { 
        this.triggerButtonClick('#sb_form_go', callback);
    });

    this.Then("Page title should be $title", function (title, callback) {

        var pageTitle = this.browser.text('title');
        if (title === pageTitle) {
          callback();
        } else {
          callback(new Error("Expected to be on page with title " + title));
        }

    });

    this.Then("URL should have q=$title in it", function (title, callback) {

        if(this.browser.location._url.search('q='+title)>-1){
            callback();
        }else{
            callback(new Error("Expected to be on page with Url params " + title));
        }

    });
};