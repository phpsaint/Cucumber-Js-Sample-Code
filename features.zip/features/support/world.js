// features/support/ 	
var zombie = require('zombie');
function World() {
  this.browser = new zombie({runScripts:true, debug:false}); // this.browser will be available in step definitions

  this.visit = function (url, next) {
    this.browser.visit(url, next);
  };  

  // Assign Form Values
  this.fillFormValue = function(valueArray,next){
  	var formKeys = Object.keys(valueArray);

  	for(var i=0;i<formKeys.length;i++){
  		this.browser.fill(formKeys[i],  valueArray[formKeys[i]] );
  	}
  	next();
  };

  this.triggerButtonClick = function(buttonId,next){
  	var buttonObject = this.browser.querySelector(buttonId);

  	this.browser.fire(buttonId,'click', function(){
  		next();
  	});
  };
}

module.exports = function() {
  this.World = World;
};